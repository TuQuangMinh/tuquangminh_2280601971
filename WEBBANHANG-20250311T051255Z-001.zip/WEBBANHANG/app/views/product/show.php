<?php
require_once 'app/models/ProductModel.php';

// Lấy ID sản phẩm từ URL
$productId = $_GET['id'] ?? 0;
$productId = filter_var($productId, FILTER_SANITIZE_NUMBER_INT);

// Tạo đối tượng ProductModel để lấy thông tin sản phẩm
$productModel = new ProductModel();
$product = $productModel->getProductById($productId);

if (!$product) {
    die('Sản phẩm không tồn tại');
}
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Thông tin sản phẩm</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <div class="product-detail">
        <h1><?php echo htmlspecialchars($product['name']); ?></h1>
        <img src="<?php echo htmlspecialchars($product['image']); ?>" alt="<?php echo htmlspecialchars($product['name']); ?>">
        <p>Giá: <?php echo htmlspecialchars($product['price']); ?> VNĐ</p>
        <p>Mô tả: <?php echo nl2br(htmlspecialchars($product['description'])); ?></p>
        <a href="index.php">Quay lại</a>
    </div>
</body>
</html>