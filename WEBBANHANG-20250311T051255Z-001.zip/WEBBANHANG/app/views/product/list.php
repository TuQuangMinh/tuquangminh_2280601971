<?php include 'app/views/shares/header.php'; ?> <!-- Bao gồm phần đầu trang -->

<!-- Banner toàn màn hình -->
<div class="banner" style="background-color: #34495e; color: #ffffff; padding: 60px; text-align: center; box-shadow: 0 4px 20px rgba(0, 0, 0, 0.5); width: 100%; margin: 0;"> 
    <h1 style="font-size: 56px; margin: 0; font-weight: bold; text-transform: uppercase;">Khuyến Mãi Xe Sang!</h1> 
    <p style="font-size: 32px; color: #e67e22;">Giảm giá lên đến 100%</p> 
    <p style="font-size: 24px;">Liên hệ: <strong>036 480 5938</strong></p> 
</div>

<!-- Phần sản phẩm -->
<h1 style="text-align: center; margin: 40px 0; font-size: 36px;">Danh sách sản phẩm</h1> 
<a href="/webbanhang/Product/add" class="btn btn-secondary mb-2" style="display: block; width: 300px; margin: 0 auto; font-size: 18px; background-color: #555; color: #fff; border: none;">Thêm sản phẩm mới</a> 

<div style="display: flex; flex-wrap: wrap; justify-content: center; max-width: 1500px; margin: 0 auto;">
    <?php foreach ($products as $product): ?> 
    <div style="flex: 0 1 calc(33.33% - 40px); margin: 20px;"> 
        <div class="list-group-item" style="border: 2px solid #34495e; border-radius: 8px; padding: 10px; background-color: #ecf0f1; height: 100%;"> 
            <h2 style="font-size: 28px; margin-bottom: 10px;"><a href="/webbanhang/Product/show/<?php echo $product->id; ?>" style="text-decoration: none; color: #2c3e50;"><?php echo htmlspecialchars($product->name, ENT_QUOTES, 'UTF-8'); ?></a></h2> 
            
            <?php if ($product->image): ?> 
            <div style="text-align: center;"> 
                <img src="/webbanhang/<?php echo $product->image; ?>" alt="Product Image" style="width: 100%; height: 200px; object-fit: cover; border-radius: 10px; box-shadow: 0 2px 10px rgba(0, 0, 0, 0.2);"> 
            </div>
            <?php endif; ?>
            <p style="font-size: 18px; margin: 10px 0;"><?php echo htmlspecialchars($product->description, ENT_QUOTES, 'UTF-8'); ?></p> 
            
            <p style="font-size: 20px; font-weight: bold;">Giá: <?php echo htmlspecialchars($product->price, ENT_QUOTES, 'UTF-8'); ?> </p> 
            
            <p style="font-size: 18px;">Danh mục: <?php echo htmlspecialchars($product->category_name, ENT_QUOTES, 'UTF-8'); ?></p> 
            
            <div style="margin-top: 10px;"> 
                <a href="/webbanhang/Product/edit/<?php echo $product->id; ?>" class="btn btn-secondary" style="margin-right: 10px; padding: 15px 30px; font-size: 20px; background-color: #555; color: #fff; border: none;">Sửa</a> 
                <a href="/webbanhang/Product/delete/<?php echo $product->id; ?>" class="btn btn-secondary" onclick="return confirm('Bạn có chắc chắn muốn xóa sản phẩm này?');" style="padding: 15px 30px; font-size: 20px; background-color: #555; color: #fff; border: none;">Xóa</a> 
            </div>
        </div>
    </div>
    <?php endforeach; ?> 
</div>

<?php include 'app/views/shares/footer.php'; ?>